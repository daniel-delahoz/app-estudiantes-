const API = "http://localhost:8000/students";
const token = localStorage.getItem("token");

// protección
if (!token) {
    window.location.href = "login.html";
}

function headers() {
    return {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
    };
}

function toast(msg) {
    const t = document.getElementById("toast");
    t.textContent = msg;
    t.style.opacity = 1;
    setTimeout(() => t.style.opacity = 0, 2000);
}

// cargar
async function cargar() {
    const res = await fetch(API, { headers: headers() });
    const data = await res.json();

    const lista = document.getElementById("lista");
    lista.innerHTML = "";

    data.forEach(e => {
        const li = document.createElement("li");

        li.innerHTML = `
            ${e.name} | ${e.age} años | Nota: ${e.grade}
            <div>
                <button onclick="editar(${e.id})">✏️</button>
                <button onclick="eliminar(${e.id})">🗑️</button>
            </div>
        `;

        lista.appendChild(li);
    });
}

// agregar
async function agregar() {
    const name = document.getElementById("name").value;
    const age = parseInt(document.getElementById("age").value);
    const grade = parseFloat(document.getElementById("grade").value);

    await fetch(API, {
        method: "POST",
        headers: headers(),
        body: JSON.stringify({ name, age, grade })
    });

    toast("Agregado");
    cargar();
}

// eliminar
async function eliminar(id) {
    await fetch(`${API}/${id}`, {
        method: "DELETE",
        headers: headers()
    });

    toast("Eliminado");
    cargar();
}

// editar
async function editar(id) {
    const name = prompt("Nombre:");
    const age = parseInt(prompt("Edad:"));
    const grade = parseFloat(prompt("Nota:"));

    await fetch(`${API}/${id}`, {
        method: "PUT",
        headers: headers(),
        body: JSON.stringify({ name, age, grade })
    });

    toast("Actualizado");
    cargar();
}

// logout
function logout() {
    localStorage.removeItem("token");
    window.location.href = "login.html";
}

cargar();